<?php


 ?>


<div class="sub_panel_content">
    <div class="article_style7 content_style1 clearfix">

        <?php if (is_user_logged_in()): ?>

            <?php


            ?>


            <form class="form_style1" action="" method="post" enctype="multipart/form-data">





                <ul class="list clearfix">

                    <li class="item half">
                        <label class="field">نام :: </label>
                        <input name="f-name" value="<?php
                        echo get_user_meta(get_current_user_id(), 'first_name', true);
                        ?>" placeholder="مثال: زهرا" type="text">
                    </li>

                    <li class="item half">
                        <label class="field"> نام خانوادگی :: </label>
                        <input name="l-name"
                               value="<?php
                               echo get_user_meta(get_current_user_id(), 'last_name', true);
                               ?>"
                               placeholder="مثال: فاطمی" value="" type="text">
                    </li>



                    <li class="item half">
                        <label class="field"> نام پدر :: </label>
                        <input name="fother_name"
                               value="<?php echo get_user_meta(get_current_user_id(), 'fother_name', true); ?>"
                               placeholder="مثال: علی" value="" type="text">
                    </li>

                    <li class="item half b_date">
                        <label class="field"> تاریخ تولد :: </label>

                        <input class="b_date" name="b_date_d"
                               value="<?php echo get_user_meta(get_current_user_id(), 'b_date_d', true); ?>"
                               placeholder="روز" value="" type="text">

                        <input class="b_date" name="b_date_m"
                               value="<?php echo get_user_meta(get_current_user_id(), 'b_date_m', true); ?>"
                               placeholder="ماه" value="" type="text">

                        <input class="b_date" name="b_date_y"
                               value="<?php echo get_user_meta(get_current_user_id(), 'b_date_y', true); ?>"
                               placeholder="سال" value="" type="text">

                    </li>


                    <li class="item half">
                        <label class="field">ایمیل :: </label>
                        <input value="<?php echo $current_user->user_email; ?>" name="" type="text" disabled>
                    </li>

                    <li class="item half">
                        <label class="field">تلفن همراه :: </label>
                        <input name="mobile" placeholder="مثال: 455****0912" value="<?php
                        echo get_user_meta(get_current_user_id(), 'mobile', true); ?>" type="text">
                    </li>

                    <li class="item half">
                        <label class="field">تلفن ثابت :: </label>
                        <input name="tel" placeholder="مثال: 55****02102" value="<?php
                        echo get_user_meta(get_current_user_id(), 'tel', true); ?>" type="text">
                    </li>



                    <li class="item half">
                        <label class="field">آی دی کاربر :: </label>
                        <input name="ip" placeholder="مثال: IP" value="<?php
                        echo get_current_user_id(); ?>" type="text" disabled>


                    </li>

                    <li class="item full">
                        <label class="field">نشانی :: </label>
                        <textarea name="address" placeholder="نشانی خود را بنویسید ..." maxlength="300"><?php
                            echo $current_user->address; ?></textarea>
                    </li>


                    <li class="item submit full">
                        <input value="ویرایش مشخصات" type="submit" name="save-profile" class="btn_style3">
                    </li>


                </ul>
                <?php wp_nonce_field('user-profile-save'); ?>
            </form>

        <?php endif; ?>
        <?php if (!is_user_logged_in()) {
echo 'شما قادر به دیدن این صفحه نمی باشید برای مشاهده در سایت لاگین کنید';

        }
        ?>

    </div>
</div>

