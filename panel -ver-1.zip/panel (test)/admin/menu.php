<?php




add_action('admin_menu','my_panel_admin_menu');

function my_panel_admin_menu(){

    add_menu_page('پنل کاربری','پنل کاربری','manage_options','my_panel_main','my_panel_main_page');

    //$main_sub=  add_submenu_page('my_panel_main','ثبت نام ها','ثبت نام ها','manage_options','my_form_main');

    //$setting=add_submenu_page('my_panel_main','تنظیمات','تنظیمات','manage_options','my_panel_setting','my_panel_setting_page');

    //$description=add_submenu_page('my_panel_main','توضیحات','توضیحات','manage_options','my_panel_desc','my_panel_desc_page');

}










