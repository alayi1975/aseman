<?php
function my_panel_main_page(){


    ?>


    <div class="wrap">
        <h1 class="wp-heading-inline">مشاهده توضیحات</h1>
    </div>

    <div class="new-panel">
        <div class="card pressthis">
            <h2>توضیحات افزونه</h2>
            <p>کد زیر را در یک برگه جدید قرار دهید تا پنل کاربری نمایش داده شود</p>
            <label class="label2" for="p1">
                <div id="p1"><?php
                    $shortcode = "[my_panel]";
                    echo $shortcode;
                    ?></div>





            </label>


        </div>
    </div>
    <?php

}