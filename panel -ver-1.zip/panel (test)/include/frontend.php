<?php

add_action('wp_enqueue_scripts','my_panel_load_user_assets');

function my_panel_load_user_assets() {

    wp_register_style('my_panel_user_style', MY_PANEL_CSS_URL.'style.css');


    wp_enqueue_style('my_panel_user_style');








}








