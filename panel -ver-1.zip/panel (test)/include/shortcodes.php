<?php



add_shortcode('my_panel', 'my_panel');
$shortcode = "[my_panel]";
function my_panel()
{

    $current_user = wp_get_current_user();
    ?>

    <div class="all_panel_sidebar">
        <div class="panel_sidebar">



            <div class="panel_menu_right">

                <?php

                $activ_tab = 'profile';
                $withelist = array('tab=profile', 'welcome', 'learning', 'takalif', 'quiz', 'ebook', 'es-post', 'game', 'help', 'exit');


                if (isset($_POST['save-profile'])) {

/*echo '<pre>';
var_dump($_POST);
echo '</pre>';*/



                    //$role = ($_POST['role']);
                    $email = sanitize_email($_POST['user-email']);
                    $first_name = sanitize_text_field($_POST['f-name']);
                    $last_name = sanitize_text_field($_POST['l-name']);

                    $mobile_number = sanitize_text_field($_POST['mobile']);
                    $tel = sanitize_text_field($_POST['tel']);
                    $address = sanitize_text_field($_POST['address']);
                    $fother_name = sanitize_text_field($_POST['fother_name']);
                    $b_date_y = sanitize_text_field($_POST['b_date_y']);
                    $b_date_m = sanitize_text_field($_POST['b_date_m']);
                    $b_date_d = sanitize_text_field($_POST['b_date_d']);
                    $user_id = get_current_user_id();



                    $update_user = wp_update_user(array(

                        'ID' => $user_id,
                        //'user_email' => $email,
                        'first_name' => $first_name,
                        'last_name' => $last_name,



                    ));

                    if (!is_wp_error($update_user)) {

                         update_user_meta($user_id, 'mobile', $mobile_number);
                        update_user_meta($user_id, 'tel', $tel);
                        update_user_meta($user_id, 'address', $address);
                        update_user_meta($user_id, 'fother_name', $fother_name);
                        update_user_meta($user_id, 'b_date_y', $b_date_y);
                        update_user_meta($user_id, 'b_date_m', $b_date_m);
                        update_user_meta($user_id, 'b_date_d', $b_date_d);


                        $is_success = true;
                        $message = 'پروفایل با موفقیت بروزرسانی گردید';

                    }



                }


                if (isset($_GET['tab']) && !empty($_GET['tab']) && in_array($_GET['tab'], $withelist)) {

                    $activ_tab = esc_sql(strip_tags($_GET['tab']));


                }
              $tpl_path = include MY_PANEL_TPL_DIR . $activ_tab . '.php';

                ?>

                <div id="user-panel">

                    <div class="container2">
                        <div id="user-panel-inner">

                            <div class="user-panel-nav">
                                <div class="user_profile">

                                    <div class="user_avatar">
                                        <?php echo get_avatar( get_the_author_email(), '100' ); ?>
                                    </div>
                                    <!-- <p class="welcome">« دانش آموز عزیز خوش آمدی »</p>-->
                                </div>
                                <ul>
                                    <li><a name="" class="<?php echo ($activ_tab == 'profile') ? 'active' : '' ?>"
                                           href="?tab=profile">پروفایل کاربر</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'welcome') ? 'active' : '' ?>"
                                           href="#">خوش آمدگویی</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'learning') ? 'active' : '' ?>"
                                           href="#">آموزش درسی</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'takalif') ? 'active' : '' ?>"
                                           href="#">تکالیف درسی</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'quiz') ? 'active' : '' ?>"
                                           href="#">آزمون آنلاین</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'game') ? 'active' : '' ?>"
                                           href="#">بازی آنلاین</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'ebook') ? 'active' : '' ?>"
                                           href="#">کتابخانه</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'es-post') ? 'active' : '' ?>"
                                           href="#">مطالب اختصاصی</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'help') ? 'active' : ''
                                        ?>" href="#">راهنما</a></li>
                                    <li><a class="<?php echo ($activ_tab == 'exit') ? 'active' : ''
                                        ?>" href="?tab=exit">خروج</a>
                                    </li>


                                </ul>

                            </div>


                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <?php


}











